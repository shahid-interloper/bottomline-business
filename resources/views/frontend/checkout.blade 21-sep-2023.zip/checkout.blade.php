<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> Checkout | {{ config('app.name') }}</title>
    <link href="{{ asset('assets/backend/css/bootstrap.min.css') }}" id="bootstrap-style" rel="stylesheet"
        type="text/css" />
    <script src="https://secure.networkmerchants.com/token/Collect.js" {{-- src="https://secure.transactiongateway.com/token/Collect.js" --}}
        data-tokenization-key="ntucz5-P5CFbx-75j6tw-MCJz8h" data-variant="inline"
        data-field-ccnumber-placeholder="0000 0000 0000 0000" data-field-ccexp-placeholder="10 / 22"
        data-field-cvv-placeholder="123" data-payment-selector="#payButton" data-custom-css='{
                "border-style" : "solid",
                "border-color" : "#c7c7c7",
                "border-width" : "1px",
                "border-radius": "3px",
                "padding"      : "6px",
                "font-size"    : "16px",
                "height"       : "33px"
                 }' data-price="{{ $amount }}" data-currency="USD" data-country="US"></script>
    <style>
        .cards_image {
            width: 250px;
        }

        #payButton {
            width: 100%;
        }
    </style>

</head>

<body>
    <div class="container mt-5 p-5">
        <div class="row">
            <div class="col-sm-12">
                <form action="{{ route('front.add.students') }}" method="post" class="form-control p-4" id="the-form">
                    <div class="row">
                        <div class="col-sm-7">

                            <h5> All Fields Are required <small class="text-danger"> * </small> </h5>
                            @csrf
                            <input type="hidden" name="totalPayment" value="{{ @$amount }}">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="input input-text half-width">
                                        <input type="text" class="form-control" placeholder="First name"
                                            name="fname">
                                    </div>
                                </div>
                                <div class="col-sm-6">

                                    <div class="input input-text half-width">
                                        <input type="text" class="form-control" placeholder="Last name"
                                            name="lname">

                                    </div>
                                </div>

                                <div class="row mt-2">
                                    <h4 class="mt-2">Billing Address</h4>

                                    <div class="col-sm-12">
                                        <label for="Line_one" class="mt-2"> Line 1 </label>
                                        <input type="text" class="form-control" placeholder="Line 1" name="line_one"
                                            required>
                                    </div>

                                    <div class="col-sm-12">
                                        <label for="Line_two" class="mt-2"> Line 2 </label>
                                        <input type="text" class="form-control" placeholder="Line 2" name="line_two"
                                            required>
                                    </div>

                                    <div class="row mt-2">
                                        <div class="col-sm-3">
                                            <label for="city"> City </label>
                                            <input type="text" class="form-control" placeholder="City" name="city"
                                                required>
                                        </div>

                                        <div class="col-sm-3">
                                            <label for="phone"> phone </label>
                                            <input type="text" class="form-control" placeholder="phone"
                                                name="phone" required>
                                        </div>

                                        <div class="col-sm-3">
                                            <label for="state"> State </label>
                                            <input type="text" class="form-control" placeholder="State"
                                                name="state" required>
                                        </div>
                                        <div class="col-sm-3">
                                            <label for="zip"> Zip </label>
                                            <input type="text" class="form-control" placeholder="Zip" name="zip"
                                                required>
                                        </div>
                                    </div>

                                    <div class="row mt-2">
                                        <div class="col-sm-12">
                                            <label for="Email"> Email </label>
                                            <div class="input input-text half-width">
                                                <input type="text" class="form-control"
                                                    placeholder="Email eg : someone@example.com" name="email"
                                                    required>

                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>


                            <div class="row mt-3">
                                <h4>Card Details</h4>

                                <div class="row">
                                    <div class="col-sm-12">
                                        <img src="{{ asset('assets/frontend/images/cards.png') }}" class="cards_image"
                                            alt="..">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-12 mb-3">
                                        <input type="text" name="name_oncard" placeholder="Name on Card"
                                            class="form-control" required />
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="input input-text half-width">
                                        <span class="input-label">Card Number</span>
                                        <div id="ccnumber"></div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="input input-text half-width">
                                        <span class="input-label">Expiration Date</span>
                                        <div id="ccexp"></div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="input input-text half-width">
                                        <span class="input-label">CVV</span>
                                        <div id="cvv"></div>

                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="col-sm-5">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Total Students</th>
                                        <th>Total Amount</th>
                                        <th>Course Dates</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            Students : {{ count(Session::get('students')) }}
                                        </td>
                                        <td>
                                            {{ 'Total Payment Amount' . ' $' . $amount }}
                                        </td>
                                        <td> {{ Session::get('dates') }} </td>
                                    </tr>
                                </tbody>
                            </table>

                            <input type="submit" id="payButton" value="Pay" class="btn btn-success btn-lg mt-3">

                        </div>
                </form>

            </div>
        </div>
    </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script>
        // Add an event listener to the form submit button
        document.getElementById('payButton').addEventListener('click', function(event) {
            // Get the form element
            var form = document.getElementById('the-form');
            console.log(payButton);
            // Validate the required fields
            if (!form.checkValidity()) {
                // Prevent form submission
                event.preventDefault();
                event.stopPropagation();
                // Display an error message using Swal.fire
                Swal.fire({
                    icon: 'error',
                    title: 'Validation Error',
                    text: 'Please fill in all required fields.',
                });
            } else {
                $('#payButton').val('Processing ...')
                $('#payButton').attr('disabled', true)
            }

            // Add more validation logic as needed
            // If the form is valid, it will be submitted as usual
        });
    </script>

</body>

</html>
