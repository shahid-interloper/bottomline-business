<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\Student;
use App\Models\User;
use App\Notifications\SMSNotification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Mail;


// use Omnipay\Omnipay;

class FrontendController extends Controller
{

    // private $gateway;
    // public function __construct()
    // {
    //     $this->gateway = Omnipay::create('PayPal_Rest');
    //     $this->gateway->setClientId(config('app.paypalClientId'));
    //     $this->gateway->setSecret(config('app.payPalClientSecret'));
    //     $this->gateway->setTestMode(true); //set it to 'false' when go live

    // }


    public function index()
    {
        return redirect()->route('home');
    }


    public function registerStep1()
    {
        return view('frontend.register-step1');
    }


    public function registerStep1Process(Request $request)
    {
        $request->session()->put('dates', trim($request->dates));
        $dates = explode(',', $request->session()->get('dates'));
        if (count($dates) > 2 || count($dates) < 2) {
            return redirect()->route('front.register.step1')->with(['message' => 'please select two dates', 'type' => 'danger']);
        }

        $course = Course::where('start_date', trim($dates[0]))->where('end_date', trim($dates[1]))->first();
        // dd($check);
        if (!empty($course)) {
            $studentsCount = Student::where('course_id', $course->id)->get()->count();
            $remainingStudents = 50 - $studentsCount;
        } else {
            $remainingStudents = 50;
        }
        return redirect()->route('front.register.step2')->with('remainingStudents', $remainingStudents);
    }

    public function registerStep2(Request $request)
    {
        if (!session::has('dates')) {
            return redirect()->route('front.register.step1')->with(['message' => 'please select two dates', 'type' => 'danger']);
        }
        return view('frontend.register-step2');
    }

    public function registerStep2Process(Request $request)
    {
        $request->validate(
            [
                'student.*.first_name' => 'required',
                'student.*.phone' => 'required',
                'student.*.email' => 'required',

            ],
            [
                'student.*.first_name.required'  => 'The first name is required',
                'student.*.phone.required'       => 'The phone number is required',
                'student.*.phone.regex'          => 'phone number format is invalid',
                'student.*.phone.unique'         => 'phone number is already taken',
                'student.*.email'                => 'email should be proper email address',

            ]
        );

        if (count($request->student) > 50) {
            return redirect()->route('front.register.step2')->with(['message' => 'You can Only add 50 students in a class', 'type' => 'danger']);
        }
        $request->session()->put('students', $request->student);
        $amount = count($request->student) * 449;
        // dd($amount);
        return view('frontend.checkout', compact('amount'));
    }

    public function checkStudents(Request $request)
    {
        //  dd($request->all());
        $dates = explode(',', $request->session()->get('dates'));
        $course = Course::where('start_date', trim($dates[0]))->where('end_date', trim($dates[1]))->first();
        $data = 0;
        if (!empty($course)) {
            $count = Student::where('course_id', $course->id)->count();
            $count = $count + $request->number_of_students;
            if ($count > 50) {
                $data =  "Course Limit Exceeds ( ONly 50 students are allowed in a course )  Please try in another available course";
            }
        } else {
            $data =  '50 students are available in a course';
        }

        return json_encode($data);
    }

    public function addStudents(Request $request)
    {
        // dd($request->all());
        $studentsCount = count($request->session()->get('students'));
        $pricePerStudent = 449;

        if ($request->totalPayment < ($pricePerStudent * $studentsCount)) {
            return redirect()->route('user.dashboard')->with(['message' => 'Price can not be less than total number of students', 'type' => 'danger']);
        }

        $fname = $request->fname;
        $lname = $request->lname;
        $email = $request->email;
        $nameOnCard = $request->name_oncard;
        $line1 = $request->line_one;
        $line2 = $request->line_two;
        $city = $request->city;
        $phone = $request->phone;
        $state = $request->state;
        $zip = $request->zip;
        $duplicateSeconds = 10;
        // dd($request->payment_token);
        $url  = "https://secure.merchantonegateway.com/api/transact.php";
        $vars = "security_key=R2NXQ3UbF23U4h2SKx6g89TRX8Ej45W5&type=sale&amount=$request->totalPayment&first_name=$fname&last_name=$lname&email=$email&account_name=$nameOnCard&address1=$line1&address2=$line2&city=$city&phone=$phone&state=$state&postal=$zip&dup_seconds=$duplicateSeconds&payment_token=$request->payment_token";

        // SAVING DATES 
        $dates = explode(',', $request->session()->get('dates'));
        $course = new Course();
        $course->user_id     = Auth::id();
        $course->start_date  = trim($dates[0]);
        $course->end_date    = trim($dates[1]);

        // $courses = Course::all();
        $checkCourse = Course::where('start_date', trim($dates[0]))->where('end_date', trim($dates[1]))->first();
        if (!empty($checkCourse)) {
            $count = Student::where('course_id', $checkCourse->id)->count();
            if ($count >= 50) {
                return redirect()->route('front.register.step1')->with(['message' => 'Course Limit Exceeds ( ONly 50 students are allowed in a course )  Please try in another available course', 'type' => 'danger']);
            } else {
                $ch = curl_init($url);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $vars);
                // curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                // curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

                // Extract reference code from the response
                preg_match("/response_code=(\d+)/", $response, $matches);
                $referenceCode = isset($matches[1]) ? $matches[1] : '';
                if ($referenceCode == 100) {
                    foreach ($request->session()->get('students') as  $value) {
                        $student = new Student();
                        $student->course_id     = $checkCourse->id;
                        $student->first_name    = $value['first_name'];
                        $student->last_name     = $value['last_name'];
                        $student->email         = $value['email'];
                        $student->phone         = $value['phone'];
                        // $student->email_sent         = false;

                        $student->save();
                        try {
                            Mail::send('emails.registernotification', ['data' => $value, 'dates' => $request->session()->get('dates')], function ($message) use ($value) {
                                $message->to($value['email'])->subject("Student Registration");
                            });
                        } catch (\Throwable $e) {
                            Log::info($e->getCode() . ' - ' . $e->getMessage());
                        }
                        // Notification::send($value, new CourseRegisterNotification($data));
                    }
                    $data['message'] = 'Students Registered Successfully';
                    $data['type']    = 'success';
                } else {
                    $data['message'] = 'Payment failed please try again later !..';
                    $data['type']    = 'danger';
                }
            }
        } else {

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $vars);
            // curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            // curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

            // dd($response);
            // die;

            // Extract reference code from the response
            preg_match("/response_code=(\d+)/", $response, $matches);
            $referenceCode = isset($matches[1]) ? $matches[1] : '';
            // dd( $referenceCode );
            if ($referenceCode == 100) {
                if ($course->save()) {
                    foreach ($request->session()->get('students') as  $value) {
                        $student = new Student();
                        $student->course_id     = $course->id;
                        $student->first_name    = $value['first_name'];
                        $student->last_name     = $value['last_name'];
                        $student->email         = $value['email'];
                        $student->phone         = $value['phone'];
                        $student->email_sent         = "false";
                        $student->save();
                        try {
                            Mail::send('emails.registernotification', ['data' => $value, 'dates' => $request->session()->get('dates')], function ($message) use ($value) {
                                $message->to($value['email'])->subject("Student Registration");
                            });
                        } catch (\Throwable $th) {
                            //throw $th;
                        }
                    }

                    $data['message'] = 'Students Registered Successfully';
                    $data['type']    = 'success';
                } else {
                    $data['message'] = 'Something went wrong please try again later !...';
                    $data['type']    = 'danger';
                }
            } else {
                $data['message'] = 'Payment Failed Please try again later !...';
                $data['type']    = 'danger';
            }
        }

        $request->session()->forget('dates');
        return redirect()->route('front.thank.you')->with($data);
    }


    public function thankyou()
    {
        return view('frontend.thank-you');
    }


    public function SendSms()
    {
        
        $user = User::first();
        // dd($user);
        $user->notify(new SMSNotification);

        dd('Notification sent!');
    }
}
