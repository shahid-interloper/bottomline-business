<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="{{ asset('assets/backend/css/bootstrap.min.css') }}" id="bootstrap-style" rel="stylesheet"
        type="text/css" />
    <script
src="https://secure.networkmerchants.com/token/Collect.js"
data-tokenization-key="ntucz5-P5CFbx-75j6tw-MCJz8h"
data-payment-selector="#payButton"
data-primary-color="#34c38f"
data-theme="bootstrap"
data-secondary-color="#ffe200"
data-button-text="Submit the Payment"
data-instruction-text="Enter Card Information"
data-payment-type="cc"
data-field-cvv-display="show"
data-price="{{ $amount }}"
data-currency="USD"
data-country="US"
data-field-google-pay-shipping-address-required="true"
data-field-google-pay-shipping-address-parameters-phone-number-required="true"
data-field-google-pay-shipping-address-parameters-allowed-country-codes="US,CA"
data-field-google-pay-billing-address-required="true"
data-field-google-pay-billing-address-parameters-phone-number-required="true"
data-field-google-pay-billing-address-parameters-format="MIN"
data-field-google-pay-email-required="true"
data-field-google-pay-button-type="buy"
data-field-google-pay-button-locale="en"
data-field-google-pay-button-color="default"
data-field-apple-pay-shipping-type="delivery"
data-field-apple-pay-shipping-methods=''
data-field-apple-pay-required-billing-contact-fields='["postalAddress","name"]'
data-field-apple-pay-required-shipping-contact-fields='["postalAddress","name"]'
{{-- data-field-apple-pay-contact-fields='["phone","email"]' --}}
{{-- data-field-apple-pay-contact-fields-mapped-to='shipping' --}}
data-field-apple-pay-line-items=''
data-field-apple-pay-total-label='foobar'
data-field-apple-pay-total-type='pending'
data-field-apple-pay-type='buy'
data-field-apple-pay-style-button-style='black'
data-field-apple-pay-style-height='40px'
data-field-apple-pay-style-border-radius='4px'>
</script>

    <script>
        function handlePaymentResponse(response) {
            if (response.success) {
                // Payment is successful
                console.log("Payment successful");
                // Perform any additional actions you need
            } else {
                // Payment failed
                console.log("Payment failed");
                // Perform any error handling or fallback actions
            }
        }
    </script>


</head>

<body>

    <div class="container mt-5 p-5">
        <div class="row">
            <div class="col-sm-12 text-center">
                <h4> {{ 'pay amount' . ' $' . $amount }} </h4>
            </div>
            <div class="col-sm-8 offset-md-2 text-center">
                <form action="{{ route('front.add.students') }}" method="post" class="form-control">
                    @csrf
                    <button id="payButton" type="button" class="btn btn-success"> Submit Payment </button>
                </form>
            </div>
        </div>
    </div>

    <div>
        {{-- <button id="payButton" type="button">Submit Payment</button> --}}

    </div>

</body>

</html>
